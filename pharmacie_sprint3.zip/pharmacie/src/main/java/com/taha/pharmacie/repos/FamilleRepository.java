package com.taha.pharmacie.repos;

import com.taha.pharmacie.entities.Famille;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FamilleRepository extends JpaRepository<Famille, Long> {

}
